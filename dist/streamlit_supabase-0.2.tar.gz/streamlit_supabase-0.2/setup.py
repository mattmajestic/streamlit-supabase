from setuptools import setup, find_packages

setup(
    name="streamlit_supabase",
    version="0.2",
    description="Supabase functions in the Streamlit framework",
    author="Matt Majestic",
    packages=find_packages(),
    install_requires=[
        # List your package dependencies here
    ],
)
